const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
var cookies = require("cookie-parser");
const mongoose = require('mongoose');
var cookieSecret = process.env.COOKIE_SECRET;
let session = require('express-session');
const PORT = process.env.PORT || 5005

const mongoCon = process.env.mongoCon || "mongodb+srv://<USERNAME>:<PASSWORD@cluster0-z2fyj.mongodb.net/<DB>?authSource=admin&replicaSet=Cluster0-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true";
mongoose.connect(mongoCon,{ useNewUrlParser: true,useCreateIndex: true, useUnifiedTopology: true });


const app = express();
app.set('views', path.join(__dirname, 'views'))
   .set('view engine', 'ejs')
   .use(bodyParser({extended: false})) // For parsing the body of a POST
   .use(cookies(cookieSecret))
   .set('trust proxy', 1)
   .use(session({
      secret: 'keyboard cat',
      resave: false,
      saveUninitialized: true,
      cookie: { secure: true }
    }))
   .use('/', require('./routes/w05Class'))
   .listen(PORT, () => console.log(`Listening on ${ PORT }`));