const Customer = require('../models/w05/customer');
const router = require('express').Router();
const bcrypt = require('bcryptjs');

// COOKIES!!!
//JSON object to be added to cookie 
let users = { 
   firstName : "Nathan", 
   lastName: "Birch"
} 
router.get('/setuser', (req, res)=>{ 
   res.cookie("userData", users); 
   res.send('user data added to cookie'); 
}); 
router.get('/getuser', (req, res)=>{ 
   res.send(req.cookies); 
}); 

// Authentication
router.get('/signup', (req, res)=> {
   res.render('signup', {
      title: "Class Login Activity"
  });
});
router.post('/signup', (req, res)=> {
   const email = req.body.email;
   const password = req.body.password;
   const confirmPassword = req.body.confirmPassword;
   Customer.findOne({ email: email })
   .then(customerDoc => {
     if (customerDoc) {
       return res.redirect('signup');
     }
     return bcrypt.hash(password, 12);
   })
   .then(hashedPassword => {
     const customer = new Customer({
       email: email,
       password: hashedPassword
     });
     return customer.save();
   })
   .then(result => {
     res.redirect('login');
   })
   .catch(err => {
     console.log(err);
   });
});
router.get('/login', (req, res)=> {
   res.render('login', {
      title: "Class Login Activity"
  });
});
router.post('/login', (req, res, next) => {
   const email = req.body.email;
   const password = req.body.password;
   Customer.findOne({ email: email })
     .then((customer) => {
       if (!customer) {
         return res.redirect("login");
       }
       bcrypt
         .compare(password, customer.password)
         .then(match => {
           if(match) {
             req.session.customer = customer;
             res.render('index', {
               title: "Week 5 Class Activity",
               customer: req.session.customer
             });
           } else {
              return res.redirect('index');
           }
         })
         .catch((err) => {
           console.log(err);
           res.redirect("login");
         });
     })
     .catch((err) => console.log(err));
});

router.get('/signout', (req, res)=> {
   req.session.customer = null
   res.redirect('/');
});
// home
router.get('/', (req, res) => {
   res.render('index', {
      title: "Week 5 Class Activity",
      customer:null
  });
})
module.exports = router;