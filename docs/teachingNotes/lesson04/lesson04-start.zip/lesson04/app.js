const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
require('dotenv').config();
const errorHandler = require("./middleware/error-handler");
const errorMessage = require("./middleware/error-message");
const accessControls = require("./middleware/access-controls");
const mongoose = require('mongoose');
const path = require('path');
const cors = require('cors');
const bodyParser = require('body-parser')
app.use(
    bodyParser.urlencoded({
      extended: true
    })
  );
  
  app.use(bodyParser.json()); // to support JSON-encoded bodies
  
// Requiring Routes

const UsersRoutes = require('./routes/users.routes');

// connection to mongoose
const mongoCon = process.env.mongoCon || "mongodb+srv://<DBNAME>:<DBPASSWORD>@cluster0-z2fyj.mongodb.net/test?authSource=admin&replicaSet=Cluster0-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true";

mongoose.connect(mongoCon,{ useNewUrlParser: true,useCreateIndex: true, useUnifiedTopology: true });


const fs = require('fs');
fs.readdirSync(__dirname + "/models").forEach(function(file) {
    require(__dirname + "/models/" + file);
});

// in case you want to serve images 
app.use(express.static("public"))
  .get('/',  function (req, res) {
    res.status(200).send({
    message: 'Express backend server'});
  })
  .set('port', (5004))
  .use(accessControls)
  .use(cors())
  .use("/users",UsersRoutes)
  .set('views', path.join(__dirname, 'views'))
  .set('view engine', 'ejs')
  .use(errorHandler)
  .use(errorMessage);

server.listen(app.get('port'));
console.log('listening on port',app.get('port'));
