const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')

const User = require('../models/user')

// Make sure this is the same as the key in middleware/is-auth.js
const SECRET = 'super secret key'

// Endpoint for creating a new account
exports.postSignup = (req, res, next) => {
    const { username, password } = req.body

    User.findOne({ username })
        .then(user => {
            if (user) {
                const err = new Error('Username is taken')
                // HTTP 409 = Conflict
                err.statusCode = 409
                return next(err)
            }
            return bcrypt
                .hash(password, 12)
                .then(hashed => {
                    const u = new User({ username, password: hashed })
                    return u.save()
                })
                .then(u => {
                    // HTTP 201 = Created
                    res.status(201).send({ username, _id: u._id })
                })
        })
        .catch(next)
}

// Endpoint for logging into an account
exports.postLogin = (req, res, next) => {
    // Get a username and password from req.body, and log in the user.

    res.status(501).send({}) // TODO Replace this with your code.
}

// Send the currently logged in user in the response
exports.getUser = (req, res, next) => {
    // Send something to the current users. This route should be protected by middleware.

    res.status(501).send({}) // TODO Replace this with your code.
}
