const express = require('express')
const bodyParser = require('body-parser')
const path = require('path')
const PORT = process.env.PORT || 5002

const app = express()
app.use(express.static(path.join(__dirname, 'public')))
    // Use json instead of urlencoded, because this is a REST API
    .use(bodyParser.json())
    .use('/api', require('./routes/api'))
    .listen(PORT, () => console.log(`Listening on ${PORT}`))
