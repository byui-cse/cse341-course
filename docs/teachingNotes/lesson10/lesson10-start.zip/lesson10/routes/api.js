// This file contains API routes for authentication and error handling.
// Every route in this file should send JSON data as the response.
//
// Notice that these rotes don't have any validation.
// You would need to add that yourself with express-validator
// before using this code in a project.
const router = require('express').Router()

const { postSignup, postLogin, getUser } = require('../controllers/api')
const isAuth = require('../middleware/is-auth')

router
    // POST /api/signup
    .post('/signup', postSignup)

    // POST /api/login
    .post('/login', postLogin)

    // GET /api/user (Requires authentication)
    .get('/user', isAuth, getUser)

    // 404 Handler
    .use((req, res, next) => {
        res.status(404).send({ message: 'Resource Not Found', path: req.path })
    })

    // Error Handler
    .use((err, req, res, next) => {
        // HTTP 500 = Server Error
        if (!err.statusCode) err.statusCode = 500
        res.status(err.statusCode).send({ message: err.message })
        console.error(err)
    })

module.exports = router
