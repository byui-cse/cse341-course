const jwt = require('jsonwebtoken')

// Make sure this is the same as the key in controllers/auth.js
const SECRET = 'super secret key'

// TODO Write a middleware function to verify user tokens.
module.exports = (req, res, next) => {
    // ...
    next()
}
