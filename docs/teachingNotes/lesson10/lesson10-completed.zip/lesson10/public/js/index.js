//#region POST /api/signup
const signup = {}

signup.el = {}
signup.el.username = document.getElementById('signup-username')
signup.el.password = document.getElementById('signup-password')
signup.el.code = document.getElementById('signup-code')
signup.el.send = document.getElementById('signup-send')
signup.el.response = document.getElementById('signup-response')

signup.username = () => signup.el.username.value
signup.password = () => signup.el.password.value

signup.send = async () => {
    signup.response.clear()

    const res = await fetch('/api/signup', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            username: signup.username(),
            password: signup.password()
        })
    })
    const data = await res.json()

    signup.response.set(res.status, res.statusText, data)
}

signup.code = () => {
    signup.el.code.value = `fetch('/api/signup', {\n\tmethod: 'POST',\n\theaders: {\n\t\t'Content-Type': 'application/json'\n\t},\n\tbody: JSON.stringify({\n\t\tusername: '${signup.username()}',\n\t\tpassword: '${signup.password()}'\n\t})\n})`
    signup.el.code.setAttribute(
        'rows',
        signup.el.code.value.split(/\r*\n/).length
    )
}

signup.response = {}
signup.response.clear = () => {
    signup.el.response.removeAttribute('rows')
    signup.el.response.value = ''
}
signup.response.set = (status, statusText, data) => {
    const res = `${status} "${statusText}"\n${JSON.stringify(data, null, 4)}`
    signup.el.response.value = res
    signup.el.response.setAttribute('rows', res.split(/\r*\n/).length)
}

signup.clear = () => {
    signup.response.clear()
    signup.el.username.value = ''
    signup.el.password.value = ''
    signup.code()
}

signup.el.username.onkeyup = signup.code
signup.el.password.onkeyup = signup.code
signup.el.send.onclick = signup.send

signup.code()
//#endregion

//#region POST /api/login
const login = {}

login.el = {}
login.el.username = document.getElementById('login-username')
login.el.password = document.getElementById('login-password')
login.el.code = document.getElementById('login-code')
login.el.send = document.getElementById('login-send')
login.el.response = document.getElementById('login-response')

login.username = () => login.el.username.value
login.password = () => login.el.password.value

login.send = async () => {
    login.response.clear()

    const res = await fetch('/api/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            username: login.username(),
            password: login.password()
        })
    })
    const data = await res.json()

    login.response.set(res.status, res.statusText, data)
}

login.code = () => {
    login.el.code.value = `fetch('/api/login', {\n\tmethod: 'POST',\n\theaders: {\n\t\t'Content-Type': 'application/json'\n\t},\n\tbody: JSON.stringify({\n\t\tusername: '${login.username()}',\n\t\tpassword: '${login.password()}'\n\t})\n})`
    login.el.code.setAttribute(
        'rows',
        login.el.code.value.split(/\r*\n/).length
    )
}

login.response = {}
login.response.clear = () => {
    login.el.response.removeAttribute('rows')
    login.el.response.value = ''
}
login.response.set = (status, statusText, data) => {
    const res = `${status} "${statusText}"\n${JSON.stringify(data, null, 4)}`
    login.el.response.value = res
    login.el.response.setAttribute('rows', res.split(/\r*\n/).length)
}

login.clear = () => {
    login.response.clear()
    login.el.username.value = ''
    login.el.password.value = ''
    login.code()
}

login.el.username.onkeyup = login.code
login.el.password.onkeyup = login.code
login.el.send.onclick = login.send

login.code()
//#endregion

//#region POST /api/user
const user = {}

user.el = {}
user.el.token = document.getElementById('user-token')
user.el.code = document.getElementById('user-code')
user.el.send = document.getElementById('user-send')
user.el.response = document.getElementById('user-response')

user.token = () => user.el.token.value

user.send = async () => {
    user.response.clear()

    const res = await fetch('/api/user', {
        headers: {
            Authorization: `Bearer ${user.token()}`
        }
    })
    const data = await res.json()

    user.response.set(res.status, res.statusText, data)
}

user.code = () => {
    user.el.code.value = `fetch('/api/user', {\n\theaders: {\n\t\tAuthorization: 'Bearer ${user.token()}'\n\t},\n})`
    user.el.code.setAttribute('rows', user.el.code.value.split(/\r*\n/).length)
}

user.response = {}
user.response.clear = () => {
    user.el.response.removeAttribute('rows')
    user.el.response.value = ''
}
user.response.set = (status, statusText, data) => {
    const res = `${status} "${statusText}"\n${JSON.stringify(data, null, 4)}`
    user.el.response.value = res
    user.el.response.setAttribute('rows', res.split(/\r*\n/).length)
}

user.clear = () => {
    user.response.clear()
    user.el.token.value = ''
    user.code()
}

user.el.token.onkeyup = user.code
user.el.send.onclick = user.send

user.code()
//#endregion

// Clear inputs on tab change
document.querySelectorAll('button[data-bs-toggle="tab"]').forEach(el => {
    el.addEventListener('shown.bs.tab', () => {
        signup.clear()
        login.clear()
        user.clear()
    })
})
