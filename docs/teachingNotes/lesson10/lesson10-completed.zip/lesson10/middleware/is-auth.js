// This file contains middleware for verifying user tokens
// Tokens are extracted from the Authorization header
// If the token is valid, a user id will be set on req.userId
const jwt = require('jsonwebtoken')

// Make sure this is the same as the key in controllers/auth.js
const SECRET = 'super secret key'

module.exports = (req, res, next) => {
    // Split on whitespace because tokens are sent with the format 'Bearer {token}'
    const token = req.header('Authorization').split(' ')[1]
    let decoded
    try {
        // Make sure you verify the token, not just decode it
        decoded = jwt.verify(token, SECRET)
    } catch (err) {
        err.message = 'Not Authenticated'
        err.statusCode = 401
        return next(err)
    }
    if (!decoded) {
        const err = new Error('Not authenticated')
        err.statusCode = 401
        return next(err)
    }

    req.userId = decoded._id
    next()
}
