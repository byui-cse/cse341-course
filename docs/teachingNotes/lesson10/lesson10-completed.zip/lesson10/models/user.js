// This file defines a simple User model using local file storage.
// You could also use MongoDB/mongoose for this and create the model yourself.
// If you're not using MongoDB, you shouldn't need to edit this file.
//
// Every method in the User class returns a Promise, so it should feel similar
// to working with a mongoose model.

const { v4 } = require('uuid')
const { join, dirname } = require('path')
const { readFile, writeFile } = require('fs/promises')

const path = join(dirname(require.main.filename), 'data', 'users.json')

// Helper functions
const loadUsers = () =>
    new Promise((resolve, reject) => {
        readFile(path)
            .then(b => JSON.parse(b.toString()))
            .then(resolve)
            .catch(reject)
    })
const saveUsers = users =>
    new Promise((resolve, reject) => {
        writeFile(path, JSON.stringify(users)).then(resolve).catch(reject)
    })

module.exports = class User {
    // Create a new User instance and assign it an _id value
    constructor(options = {}) {
        // Require username and password
        if (!options.username) {
            const err = new Error('Missing required field: username')
            throw err
        }
        if (!options.password) {
            const err = new Error('Missing required field: password')
            throw err
        }

        this._id = v4()
        this.username = options.username
        this.password = options.password
    }

    // Save the user to disk
    save() {
        return new Promise((resolve, reject) => {
            loadUsers()
                .then(users => {
                    if (users.find(u => u._id === this._id))
                        users = users.map(u =>
                            u._id === this._id
                                ? {
                                      ...u,
                                      username: this.username,
                                      password: this.password
                                  }
                                : u
                        )
                    else
                        users.push({
                            _id: this._id,
                            username: this.username,
                            password: this.password
                        })

                    return saveUsers(users)
                })
                .then(() => resolve(this))
                .catch(reject)
        })
    }

    // Find a single user by its _id
    static findById(_id) {
        return new Promise((resolve, reject) => {
            loadUsers()
                .then(users => {
                    const u = users.find(u => u._id === _id)
                    const user = new User(u)
                    user._id = u._id
                    resolve(user)
                })
                .catch(reject)
        })
    }

    // Find a list of users that match `options`
    static find(options = {}) {
        return new Promise((resolve, reject) => {
            const found = []
            loadUsers()
                .then(users => {
                    for (const u of users) {
                        let flag = true
                        for (const [k, v] of Object.entries(options)) {
                            if (!u.hasOwnProperty(k) || u[k] !== v) {
                                flag = false
                                break
                            }
                        }
                        if (flag) {
                            const user = new User(u)
                            user._id = u._id
                            found.push(user)
                        }
                    }
                    resolve(found)
                })
                .catch(reject)
        })
    }

    // Find a single user that matches `options`
    static findOne(options = {}) {
        return new Promise((resolve, reject) => {
            loadUsers()
                .then(users => {
                    for (const u of users) {
                        if (
                            Object.entries(options).every(
                                ([k, v]) => u.hasOwnProperty(k) && u[k] === v
                            )
                        ) {
                            const user = new User(u)
                            user._id = u._id
                            return resolve(user)
                        }
                    }
                    resolve(null)
                })
                .catch(reject)
        })
    }
}
