let loaded = 0;
let newNamesAdded = 0;
const loadMoreNames = (btn, currentCount, allNames) => {
    currentCount = parseInt(currentCount) + loaded;
    let names = allNames.split(",")
    let people = btn.previousElementSibling;
    let cur = parseInt(currentCount)
    for (i = cur; i < currentCount+10 && names[i]; i++,cur++) {
        addNameToDom(cur, people, names);
    }
    loaded += 10;
};

function addNameToDom(cur, people, names, newName) {
    var num = document.createElement("span");
    num.setAttribute("class", "numbers");
    num.textContent = cur+1+newNamesAdded;
    people.appendChild(num);

    var name = document.createElement("span");
    name.setAttribute("class", "names");
    if (newName) {
        name.textContent = newName;
        newNamesAdded++;
    } else {
        name.textContent = names[i];
    }
    people.appendChild(name);
    
    people.appendChild(document.createElement("br"))
}

const addName = (btn, allNames) => {
    let names = allNames.split(",");
    const name = btn.parentNode.querySelector('[name=name]').value;
    names.splice(loaded+1, 0, name);
    addNameToDom(loaded+10, document.getElementById("people"), names, name);
}