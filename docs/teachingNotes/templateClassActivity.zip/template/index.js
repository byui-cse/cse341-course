const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const PORT = process.env.PORT || 5002

const app = express();
app.set('views', path.join(__dirname, 'views'))
   .set('view engine', 'ejs')
   .use(bodyParser({extended: false})) // For parsing the body of a POST
   .get('/', (req, res, next) => {
     res.render('pages/index', {title: 'Class Activity Home Page', path: '/'});
    })
   .listen(PORT, () => console.log(`Listening on ${ PORT }`));