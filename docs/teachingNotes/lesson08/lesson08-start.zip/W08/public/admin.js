const addPerson = (btn) => {
    const name = btn.parentNode.querySelector('[name=name]').value;

    // Send GET request to routes.js
    fetch('/async/' + name, {
        method: 'GET'
    })
    .then(result => {
        // Return JSON object of results
        return result.json();
    })
    .then(data => {
        // TODO: Append person to the people list
    })
    .catch(err => {
        console.log(err);
    });
};