const ejs = require('ejs');
const express = require('express');
const router = express.Router();

const data = ["Nathan", "Sarah", "Hannah", "Emily", "Clara", "William"]

router.get('/', (req, res) => {
   res.render('w08', {
       data: data
   });
})

router.post('/', (req, res, next) => {
   data.push(req.body.name);
   console.log("Here is the data: ", data);
   res.render('w08', {
       data: data
   });
})

router.get('/async/:name', async(req, res, next) => {
   try {
      // push name from url params into data set
      data.push(req.params.name);
      // Return name to fetch request in admin.js
      res.status(200).json({ name: req.params.name } );
   } catch (err) {
      res.status(500).json({ message: 'Adding name failed.' } );
   }
})

module.exports = router