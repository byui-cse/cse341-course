const addPerson = (btn) => {
    const name = btn.parentNode.querySelector('[name=name]').value;

    // Send GET request to routes.js
    fetch('/async/' + name, {
        method: 'GET'
    })
    .then(result => {
        // Return JSON object of results
        return result.json();
    })
    .then(data => {
        // Create paragraph for person info
        var person = document.createElement("p");
        // Create a text node with person's name
        var name = document.createTextNode(data.name);
        // Append text to paragraph element
        person.appendChild(name);
        // Get people div
        var people = document.getElementById("people");
        // Append person to people div
        people.appendChild(person);
    })
    .catch(err => {
        console.log(err);
    });
};