const data = require('../data/w03-class-data.json');

module.exports = (req, res) => {
  const cars = data.cars;

  res.status(200).json({ cars });
};
