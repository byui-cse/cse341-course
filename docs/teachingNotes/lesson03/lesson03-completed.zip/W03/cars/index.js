const cars = require('express').Router();
const all = require('./all');
const single = require('./single');
const findObject = require('../utils/w03-class-findObject');

cars.param('carId', findObject('car'));

cars.get('/:carId', single);
cars.get('/', all);

module.exports = cars;
