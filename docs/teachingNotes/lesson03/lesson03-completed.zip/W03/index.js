const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();

const models = require('./models');
const cars = require('./cars');

app.use(express.static(path.join(__dirname, 'public')))
  .set('views', path.join(__dirname, 'views'))
  .set('view engine', 'ejs')
  .use(bodyParser({
    extended: false
  }))
  .use('/models', models)
  .use('/cars', cars)
  .get('/', (req, res) => {
    res.render('w03', {
      title: "W03 Class Activity",
      path: "classActivities/03"
    });
  })
  .listen(5000, () => console.log(`Listening on port 5000`));