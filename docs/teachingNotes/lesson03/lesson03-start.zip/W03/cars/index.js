const cars = require('express').Router();
const all = require('./all');
const single = require('./single');
const findObject = require('../utils/w03-class-findObject');

cars.param('carId', findObject('car'));

/**************************************************
 * Using the variables above, create get route to 
 * view a single car, and a get route to view all
 * cars. HINT use the w03.ejs in your views folder
 * to know how to name your routes.
 *************************************************/
// Get a single car using a dynamic ID
cars.get();

// Get all cars in the data
cars.get();

module.exports = cars;
