const data = require('../data/w03-class-data.json');

module.exports = (req, res) => {
  const models = data.models;

  res.status(200).json({ models });
};
