const models = require('express').Router();
const all = require('./all');
const single = require('./single');
const cars = require('./cars');
const findObject = require('../utils/w03-class-findObject');

models.param('modelId', findObject('model'));

/**************************************************
 * Using the variables above, create get route to 
 * view all cars of a given model, and a get route 
 * to view a model, and lastly a get route to view
 * all models. HINT use the w03.ejs in your views folder
 * to know how to name your routes.
 *************************************************/
// Get a all cars of a given model using a dynamic model ID
models.get();

// Get one car of a given model using a dynamic model ID
models.get();

// Get all models
models.get()

module.exports = models;
