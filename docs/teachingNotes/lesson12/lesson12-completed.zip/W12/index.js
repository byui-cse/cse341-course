const express = require('express');
const bodyParser = require('body-parser');
const chalk = require('chalk');
const path = require('path');
const app = express();

app.use(express.static(path.join(__dirname, 'public')))
  .set('views', path.join(__dirname, 'views'))
  .set('view engine', 'ejs')
  .use(bodyParser({
    extended: false
  }))
  .get('/passed', (req, res) => {
    console.log(chalk.bgGreen.underline.bold.white('PASSED'));
    res.redirect('/');
  })
  .get('/failed', (req, res) => {
    console.log(chalk.bgRed.underline.bold.white('FAILED'));
    res.redirect('/');
  })
  .get('/', (req, res) => {
    const random = Math.random() * 100;
    res.render('w12', {
      title: "W12 Class Activity",
      path: "classActivities/12",
      number: random.toFixed(0)
    });
  })
  .listen(5000, () => console.log(`Listening on port 5000`));