// Make sure to install chalk using NPM

const express = require('express');
const bodyParser = require('body-parser');
// Import pacakge here
const path = require('path');
const app = express();

app.use(express.static(path.join(__dirname, 'public')))
  .set('views', path.join(__dirname, 'views'))
  .set('view engine', 'ejs')
  .use(bodyParser({
    extended: false
  }))
  .get('/passed', (req, res) => {
    /**************************************************
     * Implement chalk code here
     * Write a message with the following attributes
     * Color: white
     * Font-decoration: bold and underlined
     * Background-color: green
     *************************************************/
    res.redirect('/');
  })
  .get('/failed', (req, res) => {
    /**************************************************
     * Implement chalk code here
     * Write a message with the following attributes
     * Color: white
     * Font-decoration: bold and underlined
     * Background-color: red
     *************************************************/
    res.redirect('/');
  })
  .get('/', (req, res) => {
    const random = Math.random() * 100;
    res.render('w12', {
      title: "W12 Class Activity",
      path: "classActivities/12",
      number: random.toFixed(0)
    });
  })
  .listen(5000, () => console.log(`Listening on port 5000`));