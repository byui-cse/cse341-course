// Initialize socket.io
// For this to work, you have to include the /socket.io/socket.io.js
// script in your html/ejs file BEFORE this script.
const socket = io()

const addButton = document.getElementById('add') // button#add
const removeButton = document.getElementById('remove') // button#remove
const nameInput = document.getElementById('name') // input#name
const list = document.getElementById('list') // div#list
const error = document.getElementById('error') // p#error

// Tell the server to add a name with socket.emit(event, data)
addButton.onclick = () => {

}

// Tell the server to remove a name with socket.emit(event, data)
removeButton.onclick = () => {

}

// Someone added a name! Let's display it.
socket.on('add', name => {

})

// Someone removed a name! Let's take it off the page.
socket.on('remove', name => {

})

// There was an error! Let's display it.
socket.on('error', err => {

})
