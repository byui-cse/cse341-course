const express = require('express')
const path = require('path')
const PORT = process.env.PORT || 5002

// This list is just stored in a variable, but you
// could use a databse if this data was more complex.
// If you have time, try to add more detail to this data!
// Try storing a list of objects instead of just strings.
let names = ['Peter', 'James', 'John']

const app = express()

app.set('views', path.join(__dirname, 'views'))
    .set('view engine', 'ejs')
    .use(express.static(path.join(__dirname, 'public')))
    .get('/', (req, res, next) => {
        res.render('pages/index', {
            title: 'Lesson 11 Class Activity - Socket.io',
            path: '/',
            names
        })
    })

// Store our server in a variable so we can use it with socket.io
const server = app.listen(PORT, () => console.log(`Listening on ${PORT}`))

// Initialize socket.io
// Make sure you `npm install socket.io socket.io-client`
const io = require('socket.io')(server)

// Listen for new connections
io.on('connection', socket => {
    console.log('Client connected!')
    socket.on('disconnect', () => {
        console.log('Client disconnected!')
    })

    // 3 methods for sending data to clients:
    // io.emit(event, data)
    //      Send to all connected clients
    // socket.emit(event, data)
    //      Send ONLY to the client that sent to us
    // socket.broadcast.emit(event, data)
    //      Send to all clients EXCEPT the client that sent to us

    // Do some validation in these functions.
    // Prevent duplicates, and make sure we can actually add/remove
    // the name that was sent.
    // If something is wrong, use socket.emit to send an error
    // to the client that sent the name.

    // Listen for add events
    socket.on('add', name => {
        // Add a name and tell clients to remove a name
    })

    // Listen for remove events
    socket.on('remove', name => {
        // Remove a name and tell clients to remove the name
    })
})
