// Initialize socket.io
// For this to work, you have to include the /socket.io/socket.io.js
// script in your HTML/EJS
const socket = io()

const addButton = document.getElementById('add')
const removeButton = document.getElementById('remove')
const nameInput = document.getElementById('name')
const list = document.getElementById('list')
const error = document.getElementById('error')

// Tell the server to add a name
addButton.onclick = () => {
    socket.emit('add', nameInput.value)
    nameInput.value = ''
}

// Tell the server to remove a name
removeButton.onclick = () => {
    socket.emit('remove', nameInput.value)
    nameInput.value = ''
}

// Someone added a name! Let's display it.
socket.on('add', name => {
    const p = document.createElement('p')
    p.innerText = name
    p.id = name // Set the id so it's easy to find/remove elements
    list.appendChild(p)
})

// Someone removed a name! Let's take it off the page.
socket.on('remove', name => {
    document.getElementById(name).remove()
})

// There was an error! Let's display it.
socket.on('error', err => {
    error.innerText = err

    // Just display the error for 3s, then remove it
    setTimeout(() => (error.innerText = ''), 3000)
})
