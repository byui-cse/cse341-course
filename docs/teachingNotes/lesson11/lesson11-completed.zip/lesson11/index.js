const express = require('express')
const path = require('path')
const PORT = process.env.PORT || 5002

// This list is just stored in a variable, but you
// could use a databse if this data was more complex.
let names = ['Peter', 'James', 'John']

const app = express()

app.set('views', path.join(__dirname, 'views'))
    .set('view engine', 'ejs')
    .use(express.static(path.join(__dirname, 'public')))
    .get('/', (req, res, next) => {
        res.render('pages/index', {
            title: 'Lesson 11 Class Activity - Socket.io',
            path: '/',
            names
        })
    })

// Store our server in a variable so we can use it with socket.io
const server = app.listen(PORT, () => console.log(`Listening on ${PORT}`))

// Initialize socket.io
// Make sure you `npm install socket.io socket.io-client`
const io = require('socket.io')(server)

// Listen for new connections
io.on('connection', socket => {
    console.log('Client connected!')
    socket.on('disconnect', () => {
        console.log('Client disconnected!')
    })

    // 3 methods for sending data to clients:
    // io.emit(event, data)
    //      Send to all connected clients
    // socket.emit(event, data)
    //      Send ONLY to the client that sent to us
    // socket.broadcast.emit(event, data)
    //      Send to all clients EXCEPT the client that sent to us

    // Listen for add events
    socket.on('add', name => {
        // Here we do some basic error checking. Don't allow empty names or duplicates.
        if (!name) return socket.emit('error', 'Name cannot be empty')
        if (names.includes(name)) return socket.emit('error', 'Already in list')

        // Add the name to our list, and tell clients to display it
        names.push(name)
        io.emit('add', name)
    })

    // Listen for remove events
    socket.on('remove', name => {
        // Make sure the name is in the list before we remove it
        if (names.includes(name)) {
            // Remove the name from our list, and tell clients to remove it
            names = names.filter(n => n !== name)
            io.emit('remove', name)
        } else socket.emit('error', 'Not in list')
    })
})
