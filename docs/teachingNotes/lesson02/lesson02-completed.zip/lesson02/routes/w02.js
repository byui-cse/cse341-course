// this is the routes file for the week 2 lecture/in class coding activity
const express = require('express');
const router = express.Router();
//array of games
const games = [
{
    title: "Fortnite",
    creator: "Epic Games"
},
{
    title: "Mario Kart",
    creator: "Nintendo"
},
{
    title: "Madden",
    creator: "EA Sports"
},
{
    title: "Call of Duty",
    creator: "Activision"
}

]

router.get('/', (req, res) => {
   res.render('pages/home', {
       games: games
   });
})

//route to display one single game and creator
router.get('/game/', (req, res) => {
   //constants to hold param values
   const title = req.query.gameTitle;
   const creator = req.query.gameCreator;

   //render game.ejs passing objects for ejs
   res.render('pages/game', {
       title: title,
       creator: creator
   });
})

//route to display one single game and creator
router.get('/game/:gameCreator/:gameTitle', (req, res) => {
   //constants to hold param values
   const title = req.params.gameTitle;
   const creator = req.params.gameCreator;

   //render game.ejs passing objects for ejs
   res.render('pages/game', {
       title: title,
       creator: creator
   });
})

//route for a list of games
router.get('/gamelist', (req, res) => {
   //render ejs page
   res.render('pages/gamelist', {
       gameList: games
   })
})

router.get('/addGame', (req, res) => {
    res.render('pages/addGame', {
        gameList: games
    })
 })

router.post('/game', (req, res)=> {
    const gameName = req.body.gameName;
    const gameCreator = req.body.gameCreator;
    games.push({title: gameName, creator: gameCreator})
    res.redirect('/gameList');
});

module.exports = router;