const path = require('path');
const PORT = process.env.PORT || 5050 // So we can run on heroku || (OR) localhost:5000

const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');

const app = express();

const liveChat = require('./routes/liveChat');
const { allowedNodeEnvironmentFlags } = require('process');

app.set('view engine', 'ejs');
app.set('views', 'views');

app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({ // Simple and not very secure session
   secret: 'random_text',
   cookie: {
      httpOnly: false // Permit access to client session
   }
}));

app.use('/', liveChat);

const server = app.listen(PORT, () => console.log(`Listening on ${ PORT }`));
const io = require('socket.io')(server);
io.on('connection', (socket) => {
   console.log('Client connected!');

   socket.on('disconnect', () => {
      console.log('A client disconnected!');
   });
   socket.on('newUser', (username, time) => { // A new user logs in.
      const message = `${username} has logged on.`;
      socket.broadcast.emit('newMessage', {/** CONTENT for the emit **/}); // <-----TODO-----
   });
   socket.on('message', (data) => { // Receive a new message
      console.log('Message received');   
      console.log(data); 
      socket.broadcast.emit('newMessage', {/** CONTENT for the emit **/}); // <-----TODO----- Note, only emits to all OTHER clients, not sender. 
   });
});