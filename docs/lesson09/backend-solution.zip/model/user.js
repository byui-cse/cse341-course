exports.users = [
	{
		firstName: "Anakin",
		lastName: "Skywalker",
		email: "sandh8er4ever@gmail.com",
		password: "roughNcoarse",
		image: "https://static.wikia.nocookie.net/starwars/images/6/6f/Anakin_Skywalker_RotS.png/",
		bio: "Anakin Skywalker was a legendary Force-sensitive human male who was a Jedi Knight of the Galactic Republic and the prophesied Chosen One of the Jedi Order, destined to bring balance to the Force.",
	},
	{
		firstName: "Obi-wan",
		lastName: "Kenobi",
		email: "helloThere@gmail.com",
		password: "highGroundFTW",
		image: "https://static.wikia.nocookie.net/starwars/images/3/37/Insider204-Kenobi.jpg",
		bio: "Obi-Wan Kenobi, also known as Ben Kenobi, was a human male Jedi Master who served on the Jedi High Council during the final years of the Republic Era. As a Jedi General, Kenobi served in the Grand Army of the Republic that fought against the Separatist Droid Army during the Clone Wars.",
	},
	{
		firstName: "Master",
		lastName: "Yoda",
		email: "gmail.comgreenone",
		password: "isNoTry",
		image: "https://static.wikia.nocookie.net/starwars/images/d/d6/Yoda_SWSB.png/",
		bio: "Yoda, a Force-sensitive male being belonging to a mysterious species, was a legendary Jedi Master who witnessed the rise and fall of the Galactic Republic, followed by the rise of the Galactic Empire. Small in stature but revered for his wisdom and power, Yoda trained generations of Jedi, ultimately serving as the Grand Master of the Jedi Order.",
	},
];
